
package model;

public class MenuModel {
   
    private String id;
    private String tipo;
    private double tarifaPorHora;

    public MenuModel() {
    }

    public MenuModel(String id, String tipo, double tarifaPorHora) {
        this.id = id;
        this.tipo = tipo;
        this.tarifaPorHora = tarifaPorHora;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getTarifaPorHora() {
        return tarifaPorHora;
    }

    public void setTarifaPorHora(double tarifaPorHora) {
        this.tarifaPorHora = tarifaPorHora;
    }

    @Override
    public String toString() {
        return "menuModel{" + "id=" + id + ", tipo=" + tipo + ", tarifaPorHora=" + tarifaPorHora + '}';
    }
    
    
}
