
package model;


public class AlquilerModel {
   
    private String nombre;
    private String apellido;
    private String nombreUsuario;
    private String contraseña;
    private MenuModel menu;

    public AlquilerModel() {
    }

    public AlquilerModel(String nombre, String apellido, String nombreUsuario, String contraseña, MenuModel menu) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
        this.menu = menu;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public MenuModel getMenu() {
        return menu;
    }

    public void setMenu(MenuModel menu) {
        this.menu = menu;
    }

    @Override
    public String toString() {
        return "AlquilerModel{" + "nombre=" + nombre + ", apellido=" + apellido + ", nombreUsuario=" + nombreUsuario + ", contrase\u00f1a=" + contraseña + ", menu=" + menu + '}';
    }

   

    
    
    
}
