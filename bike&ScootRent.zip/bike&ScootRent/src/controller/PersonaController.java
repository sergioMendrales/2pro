
package controller;

import java.util.ArrayList;
import model.AlquilerModel;
import model.MenuModel;

  
public class PersonaController {
    
     private ArrayList<AlquilerModel> usuarios;
    private ArrayList<MenuModel> menuItems;    
    
    // Constructor
    public PersonaController() {
        usuarios = new ArrayList<>();
        menuItems = new ArrayList<>();
    }

    
    public void agregarUsuarios(AlquilerModel usuario) {
        usuarios.add(usuario);
    }
    
   
    public ArrayList<MenuModel> obtenerMenu() {
        return menuItems;
    }

    
    public boolean autenticar(String nombreUsuario, String contraseña) {
        for (AlquilerModel usuario : usuarios) {
            if (usuario.getNombreUsuario().equals(nombreUsuario) && usuario.getContraseña().equals(contraseña)) {
                return true; 
            }
        }
        return false; 
    }
    
   
    public void agregarMenuItem(MenuModel menuItem) {
        menuItems.add(menuItem);
    }

    
    public ArrayList<AlquilerModel> obtenerUsuarios() {
        return usuarios;
    }
    
}
