
package controller;

import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;


public class LoginController {
    
    
    private Map<String, String> usuariosRegistrados = new HashMap<>();

    
    public void registrarUsuario(String nombreUsuario, String contrasena) {
        usuariosRegistrados.put(nombreUsuario, contrasena);
    }

   
    public boolean iniciarSesion(String nombreUsuario, String contrasena) {
        if (nombreUsuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return false;
        }

        
        if (usuariosRegistrados.containsKey(nombreUsuario) &&
            usuariosRegistrados.get(nombreUsuario).equals(contrasena)) {
            JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Nombre de usuario o contraseña incorrectos.");
            return false;
        }
    }
    
}
