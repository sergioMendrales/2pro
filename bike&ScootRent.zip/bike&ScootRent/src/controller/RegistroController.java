
package controller;

import javax.swing.JOptionPane;


public class RegistroController {
    
     private LoginController loginController;

    public RegistroController(LoginController loginController) {
        this.loginController = loginController;
    }

    public RegistroController() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean registrarUsuario(String nombre, String apellido, String nombreUsuario, String contrasena) {
        
        if (nombre.isEmpty() || apellido.isEmpty() || nombreUsuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return false;
        }

       
        if (!contrasena.matches("^[A-Za-z0-9]+$")) {
            JOptionPane.showMessageDialog(null, "La contraseña solo puede contener letras y números.");
            return false;
        }

       
        if (nombreUsuario.contains(" ")) {
            JOptionPane.showMessageDialog(null, "El nombre de usuario no puede contener espacios.");
            return false;
        }

       
        loginController.registrarUsuario(nombreUsuario, contrasena);
        JOptionPane.showMessageDialog(null, "Registro exitoso.");
        return true;
    }
    
}
